python3 hw1_.py 2
python3 hw1_.py 5
