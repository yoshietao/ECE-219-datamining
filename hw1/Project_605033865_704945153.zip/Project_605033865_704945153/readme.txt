ECE 219 hw1 ReadMe

Language used: Python3.6x

how to run the code:

in the terminal with python3 environment, run:

bash hw1.sh 

to run the code.

it will run hw1_.py twice with min_df = 2 and 5

some part of output will be duplicated because we don’t need both min_df = 2 or 5 in those parts. 